## v1.0.3 (2021-11-12)

**Fixed**

- Updated [@vue/composition-api](https://github.com/vuejs/composition-api) package to v1.3.3 to mitigate composition api error

## v1.0.2 (2021-08-18)

* broken links updated in footer
* "Basic Cards" page renamed to "Cards"
* `README.md` updated


## v1.0.1 (2021-08-13)

* Fixed missing fonts + branding updated
* public path updated in `vue.config.js`
* `README.md` updated


# v1.0.0 (2021-08-13)

* Initial Release
