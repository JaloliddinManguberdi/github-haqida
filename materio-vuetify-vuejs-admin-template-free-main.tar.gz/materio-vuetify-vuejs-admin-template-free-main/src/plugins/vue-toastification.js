import Vue from 'vue'
import Toast from 'vue-toastification'

import 'vue-toastification/dist/index.css'

const options = {

}

Vue.use(Toast, options)
